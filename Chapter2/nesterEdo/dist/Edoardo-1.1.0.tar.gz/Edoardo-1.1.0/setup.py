from distutils.core import setup 

setup (
    name         = 'Edoardo',
    version      = '1.1.0',
    py_modules   = ['nester'],
    author        = 'Edoardo',
    author_email = 'hfpython@headfirstlabs.com',
    url          = 'http://www.headfirstlabs.com',
    description  = 'A simple printer of nasted lists',
)
